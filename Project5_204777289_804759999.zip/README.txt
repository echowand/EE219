How to run the files:
1. Download PyCharm
2. Load the project as a whole
3. Run part 1 to part 7 separately for each problem